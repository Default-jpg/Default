<?php
$host="localhost";
$uname = "root";
$pwd = "";
$db = "db_ejvelarde";

$conn = new mysqli($host,$uname,$pwd,$db);


?>