<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Home page</title>
    <!-- ============link============= -->
    <link rel="stylesheet" href="./assets/css/materializecss.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" href="./assets/css/materializecss-icons.css">
    <!-- ============css============== -->
    <style>
        body {
            background-image: url("./assets/img/b1.jpg");
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-size: cover;
        }

        #wq {
            float: right;
            margin-top: 10px;
            background-color: transparent;
            margin-right: 10px;
        }
    </style>
</head>

<body>
    <!-- =============start of navbar================ -->
    <header>
        <nav>
            <div class="nav-wrapper yellow darken-2">
                <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
                <ul class="left hide-on-med-and-down">
                    <li><a href="index.php"><i class="material-icons">home</i></a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="blog.php">Blog</a></li>
                    <li><a href="shop.php">Shop</a></li>


                </ul>
                <a class='dropdown-trigger btn' href='login.php' data-target='dropdown1' id="wq">Login</a>
                <ul id='dropdown1' class='dropdown-content'>
                    <li><a href="#!">one</a></li>
                    <li><a href="#!">two</a></li>
                    <li class="divider" tabindex="-1"></li>
                    <li><a href="#!">three</a></li>
                    <li><a href="#!"><i class="material-icons">view_module</i>four</a></li>
                    <li><a href="#!"><i class="material-icons">cloud</i>five</a></li>
                </ul>
            </div>
        </nav>
        <ul class="sidenav" id="mobile-demo">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="shop.php">Shop</a></li>
            <li><a href="login.php">login</a></li>
        </ul>
    </header>
    <!-- =========end of navbar========= -->
    <main>
        <center>
            <h1><bdo dir="rtl" style="color:whitesmoke;">W E L C O M E</bdo></h1>
            <h1><bdo dir="rtl" style="color:whitesmoke;">T O</bdo></h1>
            <h1><bdo dir="rtl" style="color:whitesmoke;">M Y</bdo></h1>
            <h1><bdo dir="rtl" style="color:whitesmoke;">W O R L D</bdo></h1>
        </center>
    </main>
    <footer class="page-footer">
        <div class="footer-copyright">
            <div class="container">
                All Rights Reserved To VELARDE as of 2019 © WS101
            </div>
        </div>
    </footer>
    <script src="./assets/js/materialize-css.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var elems = document.querySelectorAll('.sidenav');
            var instances = M.Sidenav.init(elems);
        });
    </script>
</body>

</html>