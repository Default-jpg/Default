<?php 
if (isset($_POST['insert'])) {
    $uname = mysqli_real_escape_string($conn,$_POST['user']);
    $pwd = mysqli_real_escape_string($conn,$_POST['passwd']);
    $query = mysqli_query($conn,"INSERT INTO tbl_user (username,passwd) VALUE ('$uname','$pwd')");
    if (!$query) {
        echo "<p>failed registering</p>";
    }else {
        // echo "<a onclick='M.toast({html:''I am a toast'}) class='btn'>Toast!</a>";
        echo "<p>Successfully registerd</p>";
        header("location: welcome.php");
    }
}
