<?php

$conn = new mysqli("localhost","root","","EJcommentbox");

?>